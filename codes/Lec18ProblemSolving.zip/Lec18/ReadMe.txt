this is a demo of Java class
where contents of the file is displayed on console
