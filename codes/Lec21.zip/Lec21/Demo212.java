/*
Java String concat() : The Java String concat() 
method combines a specific string at the end of 
another string and ultimately returns a combined string. 
It is like appending another string.
*/
public class Demo212{
    public static void main(String args[]){
        String s1="hello";
        s1=s1.concat("how are you");
        System.out.println(s1);
    }
}