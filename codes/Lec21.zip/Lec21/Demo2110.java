public class IsEmptyExample{
    public static void main(String args[]) { 
        String s1 = ""; 
        String s2 = "hello";
        System.out.prinltn(s1.isEmpty());     // returns true
        System.out.prinltn(s2.isEmpty());     // returns false
    }
}