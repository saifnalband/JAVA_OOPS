/*
Java String length(): The Java String length() 
method tells the length of the string. 
It returns count of total number of 
characters present in the String.
*/
public class Demo210{
    public static void main(String args[]{ 
        String s1="hello"; 
        String s2="whatsup"; 
        System.out.println("string length is: "+s1.length());  
        System.out.println("string length is: "+s2.length()); 
    }
}