public class Demo215{
    public static void main(String args[]){
        String s1 = "HELLO HOW Are You?";
        String s1lower = s1.toLowerCase();
        System.out.println(s1lower);

        String s2 = "hello how are you";  
        String s2upper = s2.toUpperCase();  
        System.out.println(s2upper);
    }
}