package MyPackage1;
    
public class X{

}

public class Y extends X{

}

public class A{

}

package MyPackage2;
import MyPackage1.*;

public class Z extends X{

}
public class B{
    
}
