// Demo package p2.
import mypackage2.*;

// Instantiate the various classes in p2.
public class Demo2 {
  public static void main(String args[]) {
      Z ob1 = new Z();
      B ob2 = new B();
    }
}