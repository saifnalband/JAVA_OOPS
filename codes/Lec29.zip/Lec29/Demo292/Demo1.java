
import mypackage1.*;
// Instantiate the various classes in p1.
public class Demo1 {
  public static void main(String args[]) {
    X ob1 = new X();
    Y ob2 = new Y();
    A ob3 = new A();
  }
}
