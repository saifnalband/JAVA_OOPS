// Demonstrate the do-while loop.
class Demo512 {
    public static void main(String args[]) {
      int n = 10;
  
      do {
        System.out.println("tick " + n);
        n--;
      } while(n > 0);
    }
}