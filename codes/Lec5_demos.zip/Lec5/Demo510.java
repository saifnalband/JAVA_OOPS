// Demonstrate the while loop.
class Demo510 {
    public static void main(String args[]) {
      int n = 10;
  
      while(n > 0) {
        System.out.println("tick " + n);
        n--;
      }
    }
}