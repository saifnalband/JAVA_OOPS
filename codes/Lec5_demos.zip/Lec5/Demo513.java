// Demonstrate the for loop.
class Demo513 {
    public static void main(String args[]) {
      int n;
  
      for(n=10; n>0; n--)
        System.out.println("tick " + n);
    }
}