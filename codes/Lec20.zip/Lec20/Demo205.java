class Demo205{
    public static void main(String args[]){
        int i = 0;
        i = Integer.parseInt(args[0]);
        System.out.println(i);
    }
}