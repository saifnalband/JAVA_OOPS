class Demo201{
    public static void main(String args[]){
        int x = 100;
        System.out.println(" 1. println");
        System.out.println(" 2. println");
        System.out.print(" 1. print ");
        System.out.println(" \n ");
        System.out.print(" 2. print");
    }
}