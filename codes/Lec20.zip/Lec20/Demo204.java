class Demo204{
    public static void main(String args[]){
        if(args.length > 0){
            System.out.println(" the command line argumenst are: ");

            for(String val:args)
                System.out.println(val);
        }
        else System.out.println(" No command line argumenst found ");
    }
}