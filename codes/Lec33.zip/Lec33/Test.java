Class Error{
    Public static void main(string args[]){
        system.out.print("can you find errors in me ?")
    }
}
class AnotherError {
    public void insert(){
        System.out.print(" To insert a text");
    }
    abstract void delete(){
        System.out.print(" To delete a text");
    }
}


try {
    
} 
catch (Exception e) {
    // TODO: handle exception
}
catch (Exception e) {
    // TODO: handle exception
}
catch (Exception e) {
    // TODO: handle exception
}
finally {
    // exit of the exception handling
}

method{
    try {
        // code body that may cause exceptions
    } catch (Exception e) {
        //TODO: handle exception
    }
}


