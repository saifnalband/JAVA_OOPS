private class Demo275A {
    int data = 40;
    void msg(){
        System.out.println(" Hi, I am in class A");
    }
}
