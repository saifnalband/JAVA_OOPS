class Demo275{
    public static void main(String args[]){
        Demo275A obj = new Demo275A();
        System.out.println(obj.data);
        obj.msg();
    }
}