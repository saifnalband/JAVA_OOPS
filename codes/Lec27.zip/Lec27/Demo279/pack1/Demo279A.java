package pack1;
/* Example 1: protected modifier  */
public class Demo279A {
    protected int rollNo = 555;
    protected void msg(){ 
        System.out.println("Class A: Hello Java!" + rollNo);
    }
}