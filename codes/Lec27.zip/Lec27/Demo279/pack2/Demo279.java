package pack2;
import pack1.*;
class Demo279 extends Demo279A {
  public static void main(String args[]){
	Demo279 obj = new Demo279(); // access through inheritance only
	obj.msg();
	}
}