
public class Demo276{
    public static void main(String args[]){
        Demo276_A obj = new Demo276_A();
        //System.out.println(obj.data);
        obj.msg();
    }
}