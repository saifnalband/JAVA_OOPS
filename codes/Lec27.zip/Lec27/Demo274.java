
class Demo274{
    public static void main(String args[]){
        Demo274A obj = new Demo274A();
        System.out.println(obj.data);
        obj.msg();
    }
}