class A {
    void msg(){
        System.out.println(" Hi, I am in class A");
    }
}