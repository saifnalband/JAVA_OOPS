package pack1;
public class A {
     public int data = 40;
     public void msg(){
        System.out.println(" Hi, I am in class A");
    }
}