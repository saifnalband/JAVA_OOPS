
package pack2;
import pack1.*;
class Demo278  {
  public static void main(String args[]){
	Demo278A obj = new Demo278A();
	obj.msg();
	}
}