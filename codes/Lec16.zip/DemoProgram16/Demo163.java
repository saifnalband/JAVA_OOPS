class Demo163{
    public static void main(String args[]){
        Student s1 = new Student(111, "abc", "JAVA");
        Student s2 = new Student(222, "xyz", "JAVA", 6000);
        s1.display();
        s2.display();
    }
}