package myShape;

public abstract class Geometry{
    static final double PI = 22/7;
    public abstract double area();
    public abstract double circumferences();
}